#!/usr/bin/php -q
<?php
 ob_implicit_flush(false); 
 error_reporting(0); 
 set_time_limit(300); 
 $ttsengine[0] = "flite" ;
 $ttsengine[1] = "swift" ;

//-------- DON'T CHANGE ANYTHING ABOVE THIS LINE ----------------

 $debug = 1; 
 $newlogeachdebug = 1;
 $emaildebuglog = 0;
 $email = "yourname@yourdomain" ;
 $ttspick = 1 ;

//-------- DON'T CHANGE ANYTHING BELOW THIS LINE ----------------

//   Nerd Vittles' Today in History for Asterisk ver. 3.0, (c) Copyright Ward Mundy & Associates LLC, 2006-2022. All rights reserved.
//   Nerd Vittles Today in History for Asterisk comes with ABSOLUTELY NO WARRANTY EXPRESSED OR IMPLIED. USE IT SOLELY ARE YOUR RISK!
//   This is free software, with components licensed under the GNU General Public
//   License version 2 and other licenses. You are welcome to redistribute it subject to the terms
//   of the license agreement. Do NOT sell something for which you paid nothing. Enjoy!
//   Complete Documentation: http://nerdvittles.com/


$log = "/var/log/asterisk/nv-today.txt" ;
if ($debug and $newlogeachdebug) :
 if (file_exists($log)) :
  unlink($log) ;
 endif ;
endif ;

 $stdlog = fopen($log, 'a'); 
// $stdin = fopen('php://stdin', 'r'); 
// $stdout = fopen( 'php://stdout', 'w' ); 

if ($debug) :
  fputs($stdlog, "Nerd Vittles Today in History for Asterisk ver. 2.0 (c) Copyright 2006-2012, Ward Mundy & Associates LLC. All Rights Reserved.\n\n" . date("F j, Y - H:i:s") . "  *** New session ***\n\n" ); 
endif ;


function dlog($line) { 
 global $debug, $stdlog; 
 if ($debug) fputs($stdlog, $line); 
} 

GLOBAL $stdlog, $debug; 
 
 

// ------ Code execution begins here


$tts = $ttsengine[$ttspick] ;

$tmptext = "/tmp/today.txt" ;
$tmpwave = "/tmp/today.wav" ;
$newsfull="";

$today = mktime (0,0,0,date("m"),date("d"),date("Y"));

$newfileflag=false;
if ( file_exists($tmptext)) :
 $filestamp = filemtime($tmptext);
 if ($filestamp<$today )  :
  $newfileflag=true;
 else :
  fclose($stdin);
  fclose($stdout);
  fclose($stdlog);
  exit;
 endif ;
endif;

$startingpoint = "yn-story-content"; // replace inside the quotes with with your unique start point in the source of the HTML page. It HAS to be unique.
$endingpoint = "</div><!-- end: .bd -->"; // replace with the unique finish point in the source of the HTML page 


$fd = fopen("http://feeds.feedburner.com/historyorb/todayinhistory?format=xml","r");

if (!$fd) {
 echo "<p>Unable to open $test.\n"; 
 exit; 
} 

$value = "";
while(!feof($fd)){
	$value .= fread($fd, 4096);	
}
fclose($fd);

//if ($debug) :
//fputs($stdlog, "Raw data: " . $value . "\n\n" );
//endif ;


$startingpoint = "Today in History for"; // replace inside the quotes with with your unique start point in the source of the HTML page. It HAS to be unique.
$start= strpos($value, "$startingpoint");
$value= substr($value,$start);

$endingpoint= "</title>" ;
$end= strpos($value, "$endingpoint");

$today = substr($value,0,$end).". ";
$today = str_replace( "for ", "for the ", $today );
$today = $today . " Brought to you by history orb dot com and Nerd Viddles.  ";

$startingpoint = "Historical Events";
$start= strpos($value, "$startingpoint");
$endingpoint = "More Historical Events";
$end= strpos($value, "$endingpoint");

$events=substr($value,$start,$end-$start-69);
$events = str_replace( "&lt;p&gt;&lt;b&gt;", "", $events );
$events = str_replace( "&lt;/b&gt;", "", $events );
$events = str_replace( "&lt;/a&gt;", "", $events );
$events = str_replace( "&lt;b&gt;", "", $events );
$events = str_replace( "&lt;/b&gt;", "", $events );
$events = str_replace( "&lt;br&gt;", ". ", $events );
$events = str_replace( "&lt;/h4&gt;", ": ", $events );
$events = str_replace( " - ", ": ", $events );
$events = str_replace( " m ", " meter ", $events );
$events = str_replace( "..", ".", $events );

//if ($debug) :
//fputs($stdlog, $events . "\n\n" );
//endif ;

/*

$startingpoint = "Famous Birthdays";
$start= strpos($value, "$startingpoint");
$endingpoint = "More Famous Birthdays";
$end= strpos($value, "$endingpoint");

$birthdays=substr($value,$start,$end-$start-71);
$birthdays = str_replace( "&lt;p&gt;&lt;b&gt;", "", $birthdays );
$birthdays = str_replace( "&lt;/b&gt;", "", $birthdays );
$birthdays = str_replace( "&lt;b&gt;", "", $birthdays );
$birthdays = str_replace( "&lt;/b&gt;", "", $birthdays );
$birthdays = str_replace( "&lt;br&gt;", ". ", $birthdays );
$birthdays = str_replace( "&lt;/h4&gt;", ": ", $birthdays );
$birthdays = str_replace( " - ", ": ", $birthdays );
$birthdays = str_replace( "..", ".", $birthdays );

$startingpoint = "Famous Deaths";
$start= strpos($value, "$startingpoint");
$endingpoint = "More Famous Deaths";
$end= strpos($value, "$endingpoint");

$deaths=substr($value,$start,$end-$start-68);
$deaths = str_replace( "&lt;p&gt;&lt;b&gt;", "", $deaths );
$deaths = str_replace( "&lt;/b&gt;", "", $deaths );
$deaths = str_replace( "&lt;b&gt;", "", $deaths );
$deaths = str_replace( "&lt;/b&gt;", "", $deaths );
$deaths = str_replace( "&lt;br&gt;", ". ", $deaths );
$deaths = str_replace( "&lt;/h4&gt;", ": ", $deaths );
$deaths = str_replace( " - ", ": ", $deaths );
$deaths = str_replace( "b. ", "born ", $deaths );
$deaths = str_replace( "..", ".", $deaths );

//$enchilada = $today. $events . $birthdays . $deaths . " Thank you for calling. Have a nice day.";

*/

$enchilada = $today . chr(13) . chr(10) . $events;

$array=explode(PHP_EOL,$enchilada);
$n=sizeof($array);
$i=2;
$enchilada = $array[0].chr(13).chr(10).$array[1].chr(13).chr(10);
while ($i < $n) :
 $array[$i]="Today in ".substr($array[$i],59).chr(13).chr(10);
 $enchilada .= $array[$i];
 $i++;
endwhile;
$array[$i]="Thank you for calling. Have a nice day. Good bye.".chr(13).chr(10);
$enchilada .= $array[$i];

$enchilada = str_replace(chr(13),"",$enchilada);
$enchilada = str_replace(chr(10)," ",$enchilada);

$enchilada = str_replace( "(", "", $enchilada );
$enchilada = str_replace( ")", "", $enchilada );
$enchilada = str_replace( ";", ".", $enchilada );


//$enchilada = '"' . $enchilada . '"';

if ($debug) :
fputs($stdlog, $enchilada . "\n\n" );
endif ;

$lang = "en";
$fd = fopen("/tmp/today.txt", "w");
fwrite($fd, $enchilada);
fclose($fd);

unlink ("/tmp/today.wav") ;
//exec("flite -f /tmp/today.txt -o /tmp/today.wav");
//shell_exec
shell_exec("/usr/local/bin/gtts-cli -l $lang -f /tmp/today.txt  | /usr/bin/sox -t mp3 - -r 8000 /tmp/today.wav");


// clean up file handlers etc.  
fclose($stdin);
fclose($stdout);
fclose($stdlog);
exit;
?>
