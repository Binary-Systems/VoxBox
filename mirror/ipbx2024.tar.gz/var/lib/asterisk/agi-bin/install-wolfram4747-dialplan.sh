#!/bin/bash

sed -i '\:// BEGIN Wolfram Alpha:,\:// END Wolfram Alpha:d' /etc/asterisk/extensions_custom.conf
sed -i '/\[from-internal-custom\]/r /var/lib/asterisk/agi-bin/ibm-4747.txt' /etc/asterisk/extensions_custom.conf
asterisk -rx "dialplan reload"
echo "Remember to insert your IBM STT and Wolfram Alpha credentials in wolfram.sh"
