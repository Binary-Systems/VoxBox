#!/bin/bash

sed -i '\:// BEGIN SMS Dictator:,\:// END SMS Dictator:d' /etc/asterisk/extensions_custom.conf
sed -i '/\[from-internal-custom\]/r /var/lib/asterisk/agi-bin/sms-767.txt' /etc/asterisk/extensions_custom.conf
asterisk -rx "dialplan reload"
