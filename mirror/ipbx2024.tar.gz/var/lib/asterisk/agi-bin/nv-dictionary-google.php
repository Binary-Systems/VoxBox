#!/usr/bin/php -q 
<?php 
 ob_implicit_flush(false); 
 error_reporting(0); 
 set_time_limit(300); 
 $ttsengine[0] = "flite" ;
 $ttsengine[1] = "swift" ;

//   Nerd Vittles Google Dictionary ver. 1.0, (c) Copyright Ward Mundy, 2006-2012. All rights reserved.

//-------- DON'T CHANGE ANYTHING ABOVE THIS LINE ----------------

 $debug = 1; 
 $newlogeachdebug = 1;
 $emaildebuglog = 0;
 $emailscore = 0;
 $email = "yourname@yourdomain" ;
 $ttspick = 0 ;


//-------- DON'T CHANGE ANYTHING BELOW THIS LINE ----------------

$log = "/var/log/asterisk/nv-dictionary-google.txt" ;
if ($debug and $newlogeachdebug) :
 if (file_exists($log)) :
  unlink($log) ;
 endif ;
endif ;

 $stdlog = fopen($log, 'a'); 
 $stdin = fopen('php://stdin', 'r'); 
 $stdout = fopen( 'php://stdout', 'w' ); 

if ($debug) :
  fputs($stdlog, "Nerd Vittles Google Dictionary ver. 1.0 (c) Copyright 2006-2012, Ward Mundy. All Rights Reserved.\n\n" . date("F j, Y - H:i:s") . "  *** New session ***\n\n" ); 
endif ;

function read() {  
 global $stdin;  
 $input = str_replace("\n", "", fgets($stdin, 4096));  
 dlog("read: $input\n");  
 return $input;  
}  

function write($line) {  
 dlog("write: $line\n");  
 echo $line."\n";  
}  

function dlog($line) { 
 global $debug, $stdlog; 
 if ($debug) fputs($stdlog, $line); 
} 

function execute_agi( $command ) 
{ 
GLOBAL $stdin, $stdout, $stdlog, $debug; 
 
fputs( $stdout, $command . "\n" ); 
fflush( $stdout ); 
if ($debug) 
fputs( $stdlog, $command . "\n" ); 
 
$resp = fgets( $stdin, 4096 ); 
 
if ($debug) 
fputs( $stdlog, $resp ); 
 
if ( preg_match("/^([0-9]{1,3}) (.*)/", $resp, $matches) )  
{ 
if (preg_match('/result=([-0-9a-zA-Z]*)(.*)/', $matches[2], $match))  
{ 
$arr['code'] = $matches[1]; 
$arr['result'] = $match[1]; 
if (isset($match[3]) && $match[3]) 
$arr['data'] = $match[3]; 
return $arr; 
}  
else  
{ 
if ($debug) 
fputs( $stdlog, "Couldn't figure out returned string, Returning code=$matches[1] result=0\n" );  
$arr['code'] = $matches[1]; 
$arr['result'] = 0; 
return $arr; 
} 
}  
else  
{ 
if ($debug) 
fputs( $stdlog, "Could not process string, Returning -1\n" ); 
$arr['code'] = -1; 
$arr['result'] = -1; 
return $arr; 
} 
}  

while ( !feof($stdin) )  
{ 
$temp = fgets( $stdin ); 
 
if ($debug) 
fputs( $stdlog, $temp ); 
 
// Strip off any new-line characters 
$temp = str_replace( "\n", "", $temp ); 
 
$s = explode( ":", $temp ); 
$agivar[$s[0]] = trim( $s[1] ); 
if ( ( $temp == "") || ($temp == "\n") ) 
{ 
break; 
} 
}  

$word = $_SERVER["argv"][1];
$score = $_SERVER["argv"][2];

if ($debug) :
fputs($stdlog, "Query: " . $word . "\n" );
endif ;



$score = str_replace( "Glossary:", "Here is your definition for $word. ", $score );
if (substr($score,0,16)=="Here is your def") :
 $loc1=strpos($score,".");
 $loc2=strpos($score,":");
 $score=substr($score,0,$loc1).": ".substr($score,$loc2+1);
 $score = str_replace(chr(10),"",$score);
 $score = str_replace(chr(13),"",$score);
 $score = str_replace("esp.","especially",$score);
 $loc1=strpos($score,"Source:");
 if ($loc1>10) :
  $score=substr($score,0,$loc1);
 endif ;
 $score=$score.": Have a nice day: Goodbye.";
else :
 $score=strtolower($score);
 $loc1=strpos($score,"definition of");
 if ($loc1>1) :
  $score=substr($score,$loc1);
 endif ;
 $loc1=strpos($score,"view all results");
 if ($loc1>1) :
  $score=substr($score,0,$loc1);
 endif ;
 $score = str_replace(chr(10),". ",$score);
 $score = str_replace(chr(13),". ",$score);
 $score = str_replace("www.urbandictionary.com.","",$score);
 $score = str_replace("en.wikipedia.org.","",$score);
 $score = str_replace("www.thefreedictionary.com.","",$score);
 $score = str_replace("wikipedia, the free encyclopedia.","",$score);
 $score = str_replace("dictionary.reference.com.","",$score);
 $score=$score.": Have a nice day: Goodbye.";
endif ;

$score = chr(34). $score . chr(34);

if ($debug) :
fputs($stdlog, "Result: " . $score . "\n" );
endif ;


execute_agi("SET VARIABLE MEANING $score"); 



if ($emaildebuglog) :
 system("mime-construct --to $email --subject " . chr(34) . "Nerd Vittles Google Dictionary ver. 1.0 Session Log" . chr(34) . " --attachment $log --type text/plain --file $log") ;
endif ;


// clean up file handlers etc.  
fclose($stdin);  
fclose($stdout);
fclose($stdlog);  
exit;   
  
?>
