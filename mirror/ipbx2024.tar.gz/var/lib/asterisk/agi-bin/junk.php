#!/usr/bin/php -q
<?php
 ob_implicit_flush(false); 
 error_reporting(0); 
 set_time_limit(300); 
 $ttsengine[0] = "flite" ;
 $ttsengine[1] = "swift" ;

//-------- DON'T CHANGE ANYTHING ABOVE THIS LINE ----------------

 $debug = 1; 
 $newlogeachdebug = 1;
 $emaildebuglog = 0;
 $email = "yourname@yourdomain" ;
 $ttspick = 1 ;

//-------- DON'T CHANGE ANYTHING BELOW THIS LINE ----------------

//   Nerd Vittles' Today in History for Asterisk ver. 2.0, (c) Copyright Ward Mundy & Associates LLC, 2006-2012. All rights reserved.
//   Nerd Vittles Today in History for Asterisk comes with ABSOLUTELY NO WARRANTY EXPRESSED OR IMPLIED. USE IT SOLELY ARE YOUR RISK!
//   This is free software, with components licensed under the GNU General Public
//   License version 2 and other licenses. You are welcome to redistribute it subject to the terms
//   of the license agreement. Do NOT sell something for which you paid nothing. Enjoy!
//   Complete Documentation: http://nerdvittles.com/


GLOBAL $stdlog, $debug; 
 
 

// ------ Code execution begins here


$tmptext = "/tmp/today.txt" ;
$tmpwave = "/tmp/today.wav" ;
$newsfull="";

//$today = mktime (0,0,0,date("m"),date("d"),date("Y"));

//$newfileflag=false;
//if ( file_exists($tmptext)) :
// $filestamp = filemtime($tmptext);
// if ($filestamp<$today )  :
//  $newfileflag=true;
// endif ;
//else :
// $newfileflag=true;
//endif ;


$startingpoint = "yn-story-content"; // replace inside the quotes with with your unique start point in the source of the HTML page. It HAS to be unique.
$endingpoint = "</div><!-- end: .bd -->"; // replace with the unique finish point in the source of the HTML page 


$fd = fopen("http://feeds.feedburner.com/historyorb/todayinhistory?format=xml","r");

if (!$fd) {
 echo "<p>Unable to open $test.\n"; 
 exit; 
} 

$value = "";
while(!feof($fd)){
	$value .= fread($fd, 4096);	
}
fclose($fd);

//if ($debug) :
//fputs($stdlog, "Raw data: " . $value . "\n\n" );
//endif ;


$startingpoint = "Today in History for"; // replace inside the quotes with with your unique start point in the source of the HTML page. It HAS to be unique.
$start= strpos($value, "$startingpoint");
$value= substr($value,$start);

$endingpoint= "</title>" ;
$end= strpos($value, "$endingpoint");

$today = substr($value,0,$end).". ";
$today = str_replace( "for ", "for the ", $today );
$today = $today . " Brought to you by history orb dot com and Nerd Viddles. ".chr(10);

$startingpoint = "Historical Events";
$start= strpos($value, "$startingpoint");
$endingpoint = "More Historical Events";
$end= strpos($value, "$endingpoint");

$events=substr($value,$start,$end-$start-69);
$events = str_replace( "&lt;p&gt;&lt;b&gt;", "", $events );
$events = str_replace( "&lt;/b&gt;", "", $events );
$events = str_replace( "&lt;/a&gt;", "", $events );
$events = str_replace( "&lt;b&gt;", "", $events );
$events = str_replace( "&lt;/b&gt;", "", $events );
$events = str_replace( "&lt;br&gt;", ". ", $events );
$events = str_replace( "&lt;/h4&gt;", ": ", $events );
$events = str_replace( " - ", ": ", $events );
$events = str_replace( " m ", " meter ", $events );
$events = str_replace( "..", ".", $events );

$enchilada = $today. $events;

//echo $enchilada . chr(13).chr(10);

$array=explode(PHP_EOL,$enchilada);
$n=sizeof($array);
$i=2;
$enchilada = $array[0].chr(13).chr(10).$array[1].chr(13).chr(10);
while ($i < $n) :
 $array[$i]="Today in ".substr($array[$i],59).chr(13).chr(10);
 $enchilada .= $array[$i];
 $i++;
endwhile;
$array[$i]="Thank you for calling. Have a nice day. Good bye.".chr(13).chr(10);
$enchilada .= $array[$i];

$enchilada = str_replace(chr(13),"",$enchilada);
$enchilada = str_replace(chr(10)," ",$enchilada);

echo $enchilada;

$fd = fopen("/tmp/today.txt", "w");
fwrite($fd, $enchilada);
fclose($fd);

exec("flite -f /tmp/today.txt -o /tmp/today.wav");

