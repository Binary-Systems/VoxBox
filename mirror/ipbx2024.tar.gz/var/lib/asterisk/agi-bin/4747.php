#!/usr/bin/php -q
<?php 
 ob_implicit_flush(false); 
 error_reporting(0); 
 set_time_limit(300);    

$fd = fopen("/tmp/theanswer.txt", "r");
$theanswer = "";
while(!feof($fd)){
        $theanswer .= fread($fd, 4096);   
} 
fclose($fd);

$results = "";
while (strlen($theanswer)>20) {
  $results = $results . GetResults($theanswer) . "." . chr(13) . chr(10) ;
  $endPos = strpos($theanswer, "</plaintext>")+12;
  $theanswer=substr($theanswer,$endPos);  
}


function GetResults($response)
{
    global $results;
    $response = str_replace("|",",",$response);
    $response = str_replace("(angles with respect to nominal horizon)","",$response);
    $response = str_replace("°F","degrees fahrenheit",$response);
    $response = str_replace(" mph"," miles per hour",$response);
    $response = str_replace("USA","United States",$response);
    $response = str_replace("US","United States",$response);
    $response = str_replace("wind","wend",$response);
    $response = str_replace("Wind","Wend",$response);
    $response = str_replace("&apos;","'",$response);
    $response = str_replace("Jr.","junior",$response);
    $response = str_replace("Sr.","senior",$response);
    $response = str_replace("Dr.","doctor",$response);
    $response = str_replace("Rev.","reverend",$response);
    $response = str_replace(" mg "," milligrams ",$response);
    $response = str_replace(" g "," grams ",$response);
    $response = str_replace(" am "," a.m. ",$response);
    $response = str_replace(" pm "," p.m. ",$response);
    $response = str_replace("WNW"," west northwest,",$response);
    $response = str_replace("NNW"," north northwest,",$response);
    $response = str_replace("ENE"," east northeast,",$response);
    $response = str_replace("NNE"," north northeast,",$response);
    $response = str_replace("SSE"," south southeast,",$response);
    $response = str_replace("ESE"," east southeast,",$response);
    $response = str_replace("NE"," northeast,",$response);
    $response = str_replace("NW"," northwest,",$response);
    $response = str_replace("SW"," southwest,",$response);
    $response = str_replace("SE"," southeast,",$response);
    $response = str_replace("miles N","miles north",$response);
    $response = str_replace("miles W","miles west",$response);
    $response = str_replace("miles S","miles south",$response);
    $response = str_replace("miles E","miles east",$response);
    $response = str_replace("°"," degrees ",$response);
    $response = str_replace(" type"," ",$response);
    $response = str_replace("slant distance",". Flights seen from current geoIP location by carrier, flight number, plane type, and slant distance are as follows",$response);
    $response = str_replace("angle","angle with respect to nominal horizon",$response);
    $response = str_replace(" altitude ","by carrier, flight number, altitude, and ",$response);
    $startPos = strpos($response, "<plaintext>") + 11;
    $endPos = strpos($response, "</plaintext>");
    $length =  $endPos - $startPos;
 
    if ($length > 2) :
        $response = str_replace(chr(10),",",$response);
        $response = str_replace(".",",",$response);
        return substr($response, $startPos, $length);   
    else :
        $results = str_replace(chr(10)," ",$results);
        $results = str_replace(chr(13)," ",$results);
        $results = str_replace(".",",",$results);
        $results=$results.chr(13).chr(10).chr(34);
        echo $results ;
        echo chr(13).chr(10) ;
        echo chr(13).chr(10) ;
        $fd = fopen("/tmp/results.txt", "w");
        fwrite($fd, $results);
        fclose($fd);
        exit;
    endif ;
}


?>
