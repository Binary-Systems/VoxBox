#!/bin/bash

sed -i '\:// BEGIN nv-news-yahoo:,\:// END nv-news-yahoo:d' /etc/asterisk/extensions_custom.conf
sed -i '\:// BEGIN Weather by ZIP:,\:// END Weather by ZIP:d' /etc/asterisk/extensions_custom.conf
sed -i '/\[from-internal-custom\]/r /var/lib/asterisk/agi-bin/speechgen-dialplan.txt' /etc/asterisk/extensions_custom.conf
asterisk -rx "dialplan reload"
