-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: avantfax
-- ------------------------------------------------------
-- Server version	10.3.27-MariaDB-0+deb10u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

DROP DATABASE IF EXISTS `avantfax`;
CREATE DATABASE `avantfax`;
USE `avantfax`;

--
-- Table structure for table `AddressBook`
--

DROP TABLE IF EXISTS `AddressBook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AddressBook` (
  `abook_id` int(11) NOT NULL AUTO_INCREMENT,
  `company` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`abook_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AddressBook`
--

LOCK TABLES `AddressBook` WRITE;
/*!40000 ALTER TABLE `AddressBook` DISABLE KEYS */;
INSERT INTO `AddressBook` VALUES (1,'XXXXXXX');
/*!40000 ALTER TABLE `AddressBook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AddressBookEmail`
--

DROP TABLE IF EXISTS `AddressBookEmail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AddressBookEmail` (
  `abookemail_id` int(11) NOT NULL AUTO_INCREMENT,
  `abook_id` int(11) DEFAULT NULL,
  `contact_name` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) NOT NULL,
  PRIMARY KEY (`abookemail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AddressBookEmail`
--

LOCK TABLES `AddressBookEmail` WRITE;
/*!40000 ALTER TABLE `AddressBookEmail` DISABLE KEYS */;
/*!40000 ALTER TABLE `AddressBookEmail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AddressBookFAX`
--

DROP TABLE IF EXISTS `AddressBookFAX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AddressBookFAX` (
  `abookfax_id` int(11) NOT NULL AUTO_INCREMENT,
  `abook_id` int(11) DEFAULT NULL,
  `faxnumber` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `description` varchar(30) DEFAULT NULL,
  `to_person` varchar(150) DEFAULT NULL,
  `to_location` varchar(150) DEFAULT NULL,
  `to_voicenumber` varchar(150) DEFAULT NULL,
  `faxcatid` int(11) DEFAULT NULL,
  `faxfrom` int(11) DEFAULT 0,
  `faxto` int(11) DEFAULT 0,
  `printer` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`abookfax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AddressBookFAX`
--

LOCK TABLES `AddressBookFAX` WRITE;
/*!40000 ALTER TABLE `AddressBookFAX` DISABLE KEYS */;
INSERT INTO `AddressBookFAX` VALUES (1,1,'XXXXXXX',NULL,NULL,NULL,NULL,NULL,NULL,0,0,NULL);
/*!40000 ALTER TABLE `AddressBookFAX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `BarcodeRoute`
--

DROP TABLE IF EXISTS `BarcodeRoute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `BarcodeRoute` (
  `barcode_id` int(11) NOT NULL AUTO_INCREMENT,
  `barcode` text DEFAULT NULL,
  `alias` varchar(40) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `printer` varchar(100) DEFAULT NULL,
  `faxcatid` int(11) DEFAULT NULL,
  PRIMARY KEY (`barcode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BarcodeRoute`
--

LOCK TABLES `BarcodeRoute` WRITE;
/*!40000 ALTER TABLE `BarcodeRoute` DISABLE KEYS */;
/*!40000 ALTER TABLE `BarcodeRoute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `CoverPages`
--

DROP TABLE IF EXISTS `CoverPages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `CoverPages` (
  `cover_id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`cover_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `CoverPages`
--

LOCK TABLES `CoverPages` WRITE;
/*!40000 ALTER TABLE `CoverPages` DISABLE KEYS */;
INSERT INTO `CoverPages` VALUES (1,'Generic A4','cover.ps'),(2,'Generic Letter','cover-letter.ps'),(3,'Generic HTML','coverpage.html');
/*!40000 ALTER TABLE `CoverPages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DIDRoute`
--

DROP TABLE IF EXISTS `DIDRoute`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DIDRoute` (
  `didr_id` int(11) NOT NULL AUTO_INCREMENT,
  `routecode` varchar(10) NOT NULL,
  `alias` varchar(40) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `printer` varchar(100) DEFAULT NULL,
  `faxcatid` int(11) DEFAULT NULL,
  PRIMARY KEY (`didr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DIDRoute`
--

LOCK TABLES `DIDRoute` WRITE;
/*!40000 ALTER TABLE `DIDRoute` DISABLE KEYS */;
/*!40000 ALTER TABLE `DIDRoute` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DistroList`
--

DROP TABLE IF EXISTS `DistroList`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DistroList` (
  `dl_id` int(11) NOT NULL AUTO_INCREMENT,
  `listname` varchar(255) NOT NULL,
  `listdata` text DEFAULT NULL,
  `lastmod_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `lastmod_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`dl_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DistroList`
--

LOCK TABLES `DistroList` WRITE;
/*!40000 ALTER TABLE `DistroList` DISABLE KEYS */;
/*!40000 ALTER TABLE `DistroList` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `DynConf`
--

DROP TABLE IF EXISTS `DynConf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `DynConf` (
  `dynconf_id` int(11) NOT NULL AUTO_INCREMENT,
  `device` varchar(20) DEFAULT NULL,
  `callid` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`dynconf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `DynConf`
--

LOCK TABLES `DynConf` WRITE;
/*!40000 ALTER TABLE `DynConf` DISABLE KEYS */;
/*!40000 ALTER TABLE `DynConf` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FaxArchive`
--

DROP TABLE IF EXISTS `FaxArchive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FaxArchive` (
  `fid` int(11) NOT NULL AUTO_INCREMENT,
  `faxnumid` int(11) DEFAULT NULL,
  `companyid` int(11) DEFAULT NULL,
  `faxpath` varchar(255) NOT NULL,
  `pages` int(11) DEFAULT NULL,
  `faxcatid` int(11) DEFAULT NULL,
  `didr_id` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `lastoperation` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `lastmoduser` int(11) DEFAULT NULL,
  `lastmoddate` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `archstamp` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `modemdev` varchar(10) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `origfaxnum` varchar(20) DEFAULT NULL,
  `faxcontent` text DEFAULT NULL,
  `inbox` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`fid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FaxArchive`
--

LOCK TABLES `FaxArchive` WRITE;
/*!40000 ALTER TABLE `FaxArchive` DISABLE KEYS */;
/*!40000 ALTER TABLE `FaxArchive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `FaxCategory`
--

DROP TABLE IF EXISTS `FaxCategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `FaxCategory` (
  `catid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `FaxCategory`
--

LOCK TABLES `FaxCategory` WRITE;
/*!40000 ALTER TABLE `FaxCategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `FaxCategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Modems`
--

DROP TABLE IF EXISTS `Modems`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Modems` (
  `devid` int(11) NOT NULL AUTO_INCREMENT,
  `device` varchar(10) NOT NULL,
  `alias` varchar(40) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `printer` varchar(100) DEFAULT NULL,
  `faxcatid` int(11) DEFAULT NULL,
  PRIMARY KEY (`devid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Modems`
--

LOCK TABLES `Modems` WRITE;
/*!40000 ALTER TABLE `Modems` DISABLE KEYS */;
INSERT INTO `Modems` VALUES (1,'ttyIAX0','ttyIAX0','somebody@somewhere.com',NULL,NULL),(2,'ttyIAX1','ttyIAX1','somebody@somewhere.com',NULL,NULL),(3,'ttyIAX2','ttyIAX2','somebody@somewhere.com',NULL,NULL),(4,'ttyIAX3','ttyIAX3','somebody@somewhere.com',NULL,NULL);
/*!40000 ALTER TABLE `Modems` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SysLog`
--

DROP TABLE IF EXISTS `SysLog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SysLog` (
  `syslogid` int(11) NOT NULL AUTO_INCREMENT,
  `logdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `logtext` text DEFAULT NULL,
  PRIMARY KEY (`syslogid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SysLog`
--

LOCK TABLES `SysLog` WRITE;
/*!40000 ALTER TABLE `SysLog` DISABLE KEYS */;
INSERT INTO `SysLog` VALUES (1,'2020-12-24 18:00:18','class UserAccount> Login successful for \'admin\' from IP: \'10.8.0.5\''),(2,'2020-12-24 18:00:32','class UserAccount> Successfully changed password for admin'),(3,'2020-12-24 18:00:32','class UserAccount> set new password for \"admin\" from IP: 10.8.0.5');
/*!40000 ALTER TABLE `SysLog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserAccount`
--

DROP TABLE IF EXISTS `UserAccount`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserAccount` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(40) DEFAULT NULL,
  `username` varchar(40) NOT NULL,
  `password` varchar(32) NOT NULL,
  `email` varchar(99) NOT NULL,
  `email_sig` text DEFAULT NULL,
  `user_tsi` varchar(100) DEFAULT NULL,
  `from_company` varchar(150) DEFAULT NULL,
  `from_location` varchar(150) DEFAULT NULL,
  `from_voicenumber` varchar(150) DEFAULT NULL,
  `from_faxnumber` varchar(150) DEFAULT NULL,
  `coverpage_id` int(11) DEFAULT NULL,
  `faxperpageinbox` int(11) DEFAULT NULL,
  `faxperpagearchive` int(11) DEFAULT NULL,
  `superuser` tinyint(1) DEFAULT 0,
  `can_del` tinyint(1) DEFAULT 0,
  `last_mod` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_login` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_ip` varchar(15) DEFAULT NULL,
  `language` varchar(5) DEFAULT NULL,
  `modemdevs` text DEFAULT NULL,
  `didrouting` text DEFAULT NULL,
  `faxcats` text DEFAULT NULL,
  `pwdexpire` date DEFAULT NULL,
  `pwdcycle` int(11) DEFAULT 0,
  `pwd_reuse` tinyint(1) DEFAULT 0,
  `is_admin` tinyint(1) DEFAULT 0,
  `wasreset` tinyint(1) DEFAULT 0,
  `acc_enabled` tinyint(1) DEFAULT 1,
  `deleted` tinyint(1) DEFAULT 0,
  `any_modem` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserAccount`
--

LOCK TABLES `UserAccount` WRITE;
/*!40000 ALTER TABLE `UserAccount` DISABLE KEYS */;
INSERT INTO `UserAccount` VALUES (1,'AvantFAX Admin','admin','5f4dcc3b5aa765d61d8327deb882cf99','somebody@somewhere.com','','','','','','',0,0,0,1,1,'2020-12-26 18:43:49','2020-12-24 18:00:18','10.8.0.5','en','','','','2020-12-01',0,0,1,1,1,0,1);
/*!40000 ALTER TABLE `UserAccount` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `UserPasswords`
--

DROP TABLE IF EXISTS `UserPasswords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `UserPasswords` (
  `upid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `pwdhash` varchar(32) NOT NULL,
  PRIMARY KEY (`upid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `UserPasswords`
--

LOCK TABLES `UserPasswords` WRITE;
/*!40000 ALTER TABLE `UserPasswords` DISABLE KEYS */;
INSERT INTO `UserPasswords` VALUES (1,1,'5f4dcc3b5aa765d61d8327deb882cf99');
/*!40000 ALTER TABLE `UserPasswords` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-12-26 13:44:44
