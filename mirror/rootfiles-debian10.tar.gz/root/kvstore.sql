-- phpMyAdmin SQL Dump
-- version 4.0.10.20
-- https://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 01, 2017 at 01:55 PM
-- Server version: 5.1.73
-- PHP Version: 5.3.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `asterisk`
--

-- --------------------------------------------------------

--
-- Table structure for table `kvstore`
--

CREATE TABLE IF NOT EXISTS `kvstore` (
  `module` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `key` char(255) COLLATE utf8_unicode_ci NOT NULL,
  `val` longblob,
  `type` char(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id` char(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  UNIQUE KEY `index3` (`module`,`key`(50),`id`(50)),
  KEY `index1` (`key`(50)),
  KEY `index5` (`module`,`id`(50))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `kvstore`
--

INSERT INTO `kvstore` (`module`, `key`, `val`, `type`, `id`) VALUES
('FreePBX\\modules\\Customappsreg', '1', 0x7b22646573746964223a312c22746172676574223a22637573746f6d2d6661782d6961786d6f64656d2c732c31222c226465736372697074696f6e223a22466178202848796c6146617829222c226e6f746573223a22222c2264657374726574223a2230222c2264657374223a6e756c6c7d, 'json-arr', 'dests'),
('FreePBX\\modules\\Customappsreg', 'currentid', 0x32, NULL, 'noid');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
