-- MariaDB dump 10.19  Distrib 10.11.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: asterisk
-- ------------------------------------------------------
-- Server version	10.11.6-MariaDB-0+deb12u1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `devices`
--

DROP TABLE IF EXISTS `devices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `devices` (
  `id` varchar(20) NOT NULL DEFAULT '',
  `tech` varchar(10) NOT NULL DEFAULT '',
  `dial` varchar(255) NOT NULL DEFAULT '',
  `devicetype` varchar(5) NOT NULL DEFAULT '',
  `user` varchar(50) DEFAULT NULL,
  `description` varchar(50) DEFAULT NULL,
  `emergency_cid` varchar(100) DEFAULT NULL,
  `hint_override` varchar(100) DEFAULT NULL,
  KEY `id` (`id`),
  KEY `tech` (`tech`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `devices`
--

LOCK TABLES `devices` WRITE;
/*!40000 ALTER TABLE `devices` DISABLE KEYS */;
INSERT INTO `devices` VALUES
('702','pjsip','PJSIP/702','fixed','702','702','',NULL),
('701','pjsip','PJSIP/701','fixed','701','701','',NULL),
('53669','custom','SIP/53669@lenny.from-nv.com','fixed','53669','LENNY','',NULL),
('703','pjsip','PJSIP/703','fixed','703','703','',NULL),
('704','pjsip','PJSIP/704','fixed','704','704','',NULL),
('705','pjsip','PJSIP/705','fixed','705','705','',NULL);
/*!40000 ALTER TABLE `devices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sip`
--

DROP TABLE IF EXISTS `sip`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sip` (
  `id` varchar(20) NOT NULL DEFAULT '-1',
  `keyword` varchar(30) NOT NULL DEFAULT '',
  `data` varchar(8100) NOT NULL,
  `flags` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`,`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sip`
--

LOCK TABLES `sip` WRITE;
/*!40000 ALTER TABLE `sip` DISABLE KEYS */;
INSERT INTO `sip` VALUES
('701','account','701',48),
('701','accountcode','',20),
('701','aggregate_mwi','yes',28),
('701','allow','',17),
('701','avpf','no',11),
('701','bundle','no',29),
('701','callerid','701 <701>',49),
('701','context','from-internal',4),
('701','defaultuser','',5),
('701','device_state_busy_at','0',38),
('701','dial','PJSIP/701',18),
('701','direct_media','yes',35),
('701','disallow','',16),
('701','dtmfmode','rfc4733',3),
('701','force_rport','yes',26),
('701','icesupport','no',12),
('701','mailbox','701@device',19),
('701','match','',39),
('701','max_audio_streams','1',30),
('701','max_contacts','11',21),
('701','max_video_streams','1',31),
('701','maximum_expiration','7200',40),
('701','media_encryption','no',32),
('701','media_encryption_optimistic','no',36),
('701','media_use_received_transport','no',23),
('701','message_context','',45),
('701','minimum_expiration','60',41),
('701','mwi_subscription','auto',27),
('701','namedcallgroup','',14),
('701','namedpickupgroup','',15),
('701','outbound_proxy','',44),
('701','qualifyfreq','60',9),
('701','refer_blind_progress','yes',37),
('701','remove_existing','no',22),
('701','rewrite_contact','yes',25),
('701','rtcp_mux','no',13),
('701','rtp_symmetric','yes',24),
('701','rtp_timeout','0',42),
('701','rtp_timeout_hold','0',43),
('701','secret','c17627f1041532405b18191ea28848d',2),
('701','secret_origional','c29147f11889602b13886ea1548d',46),
('701','sendrpid','pai',8),
('701','sipdriver','chan_pjsip',47),
('701','timers','yes',33),
('701','timers_min_se','90',34),
('701','transport','',10),
('701','trustrpid','yes',6),
('701','user_eq_phone','no',7),
('702','account','702',48),
('702','accountcode','',20),
('702','aggregate_mwi','no',28),
('702','allow','',17),
('702','avpf','no',11),
('702','bundle','no',29),
('702','callerid','702 <702>',49),
('702','context','from-internal',4),
('702','defaultuser','',5),
('702','device_state_busy_at','0',38),
('702','dial','PJSIP/702',18),
('702','direct_media','yes',35),
('702','disallow','',16),
('702','dtmfmode','rfc4733',3),
('702','force_rport','yes',26),
('702','icesupport','no',12),
('702','mailbox','702@device',19),
('702','match','',39),
('702','max_audio_streams','1',30),
('702','max_contacts','1',21),
('702','max_video_streams','1',31),
('702','maximum_expiration','7200',40),
('702','media_encryption','no',32),
('702','media_encryption_optimistic','no',36),
('702','media_use_received_transport','no',23),
('702','message_context','',45),
('702','minimum_expiration','60',41),
('702','mwi_subscription','auto',27),
('702','namedcallgroup','',14),
('702','namedpickupgroup','',15),
('702','outbound_proxy','',44),
('702','qualifyfreq','60',9),
('702','refer_blind_progress','yes',37),
('702','remove_existing','yes',22),
('702','rewrite_contact','yes',25),
('702','rtcp_mux','no',13),
('702','rtp_symmetric','yes',24),
('702','rtp_timeout','0',42),
('702','rtp_timeout_hold','0',43),
('702','secret','32405c17627fa28848d10415b18191e',2),
('702','secret_origional','602c29147fa1548d11889b13886e',46),
('702','sendrpid','pai',8),
('702','sipdriver','chan_pjsip',47),
('702','timers','yes',33),
('702','timers_min_se','90',34),
('702','transport','',10),
('702','trustrpid','yes',6),
('702','user_eq_phone','no',7),
('703','account','703',56),
('703','accountcode','',19),
('703','aggregate_mwi','no',28),
('703','allow','',18),
('703','avpf','no',10),
('703','bundle','no',33),
('703','callerid','703 <703>',57),
('703','context','from-internal',55),
('703','defaultuser','',45),
('703','device_state_busy_at','0',31),
('703','dial','PJSIP/703',54),
('703','direct_media','yes',40),
('703','disallow','',17),
('703','dtmfmode','rfc2833',5),
('703','force_callerid','no',41),
('703','force_rport','yes',25),
('703','icesupport','no',12),
('703','mailbox','703@device',20),
('703','match','',36),
('703','max_audio_streams','1',42),
('703','max_contacts','1',21),
('703','max_video_streams','1',43),
('703','maximum_expiration','7200',35),
('703','md5_cred','',4),
('703','media_encryption','no',29),
('703','media_encryption_optimistic','no',30),
('703','media_use_received_transport','no',23),
('703','message_context','',46),
('703','minimum_expiration','60',34),
('703','mwi_subscription','auto',27),
('703','namedcallgroup','',15),
('703','namedpickupgroup','',16),
('703','outbound_auth','no',49),
('703','outbound_proxy','',58),
('703','qualifyfreq','60',8),
('703','refer_blind_progress','yes',47),
('703','remove_existing','yes',22),
('703','rewrite_contact','yes',26),
('703','rtcp_mux','no',32),
('703','rtp_symmetric','yes',24),
('703','rtp_timeout','0',37),
('703','rtp_timeout_hold','0',38),
('703','secret','b18191e32405c17627fa28848d10415',3),
('703','send_connected_line','no',13),
('703','sendrpid','pai',7),
('703','sipdriver','chan_pjsip',2),
('703','timers','yes',11),
('703','timers_min_se','90',39),
('703','transport','udp,tcp,tls',9),
('703','trustrpid','yes',6),
('703','user_eq_phone','no',14),
('703','vmexten','',48),
('703','webrtc','no',44),
('704','account','704',56),
('704','accountcode','',19),
('704','aggregate_mwi','no',28),
('704','allow','',18),
('704','avpf','no',10),
('704','bundle','no',33),
('704','callerid','704 <704>',57),
('704','context','from-internal',55),
('704','defaultuser','',45),
('704','device_state_busy_at','0',31),
('704','dial','PJSIP/704',54),
('704','direct_media','yes',40),
('704','disallow','',17),
('704','dtmfmode','rfc2833',5),
('704','force_callerid','no',41),
('704','force_rport','yes',25),
('704','icesupport','no',12),
('704','mailbox','704@device',20),
('704','match','',36),
('704','max_audio_streams','1',42),
('704','max_contacts','1',21),
('704','max_video_streams','1',43),
('704','maximum_expiration','7200',35),
('704','md5_cred','',4),
('704','media_encryption','no',29),
('704','media_encryption_optimistic','no',30),
('704','media_use_received_transport','no',23),
('704','message_context','',46),
('704','minimum_expiration','60',34),
('704','mwi_subscription','auto',27),
('704','namedcallgroup','',15),
('704','namedpickupgroup','',16),
('704','outbound_auth','no',49),
('704','outbound_proxy','',58),
('704','qualifyfreq','60',8),
('704','refer_blind_progress','yes',47),
('704','remove_existing','yes',22),
('704','rewrite_contact','yes',26),
('704','rtcp_mux','no',32),
('704','rtp_symmetric','yes',24),
('704','rtp_timeout','0',37),
('704','rtp_timeout_hold','0',38),
('704','secret','a28848db18191e1041532405c17627f',3),
('704','send_connected_line','no',13),
('704','sendrpid','pai',7),
('704','sipdriver','chan_pjsip',2),
('704','timers','yes',11),
('704','timers_min_se','90',39),
('704','transport','udp,tcp,tls',9),
('704','trustrpid','yes',6),
('704','user_eq_phone','no',14),
('704','vmexten','',48),
('704','webrtc','no',44),
('705','account','705',56),
('705','accountcode','',19),
('705','aggregate_mwi','no',28),
('705','allow','',18),
('705','avpf','no',10),
('705','bundle','no',33),
('705','callerid','705 <705>',57),
('705','context','from-internal',55),
('705','defaultuser','',45),
('705','device_state_busy_at','0',31),
('705','dial','PJSIP/705',54),
('705','direct_media','yes',40),
('705','disallow','',17),
('705','dtmfmode','rfc2833',5),
('705','force_callerid','no',41),
('705','force_rport','yes',25),
('705','icesupport','no',12),
('705','mailbox','705@device',20),
('705','match','',36),
('705','max_audio_streams','1',42),
('705','max_contacts','1',21),
('705','max_video_streams','1',43),
('705','maximum_expiration','7200',35),
('705','md5_cred','',4),
('705','media_encryption','no',29),
('705','media_encryption_optimistic','no',30),
('705','media_use_received_transport','no',23),
('705','message_context','',46),
('705','minimum_expiration','60',34),
('705','mwi_subscription','auto',27),
('705','namedcallgroup','',15),
('705','namedpickupgroup','',16),
('705','outbound_auth','no',49),
('705','outbound_proxy','',58),
('705','qualifyfreq','60',8),
('705','refer_blind_progress','yes',47),
('705','remove_existing','yes',22),
('705','rewrite_contact','yes',26),
('705','rtcp_mux','no',32),
('705','rtp_symmetric','yes',24),
('705','rtp_timeout','0',37),
('705','rtp_timeout_hold','0',38),
('705','secret','10415a28848db18191ec17627f32405',3),
('705','send_connected_line','no',13),
('705','sendrpid','pai',7),
('705','sipdriver','chan_pjsip',2),
('705','timers','yes',11),
('705','timers_min_se','90',39),
('705','transport','udp,tcp,tls',9),
('705','trustrpid','yes',6),
('705','user_eq_phone','no',14),
('705','vmexten','',48),
('705','webrtc','no',44);
/*!40000 ALTER TABLE `sip` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dahdi`
--

DROP TABLE IF EXISTS `dahdi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dahdi` (
  `id` varchar(20) NOT NULL DEFAULT '-1',
  `keyword` varchar(30) NOT NULL DEFAULT '',
  `data` varchar(255) NOT NULL DEFAULT '',
  `flags` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`,`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dahdi`
--

LOCK TABLES `dahdi` WRITE;
/*!40000 ALTER TABLE `dahdi` DISABLE KEYS */;
/*!40000 ALTER TABLE `dahdi` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `iax`
--

DROP TABLE IF EXISTS `iax`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `iax` (
  `id` varchar(20) NOT NULL DEFAULT '-1',
  `keyword` varchar(30) NOT NULL DEFAULT '',
  `data` varchar(255) NOT NULL,
  `flags` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`,`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iax`
--

LOCK TABLES `iax` WRITE;
/*!40000 ALTER TABLE `iax` DISABLE KEYS */;
/*!40000 ALTER TABLE `iax` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-25 15:35:53
