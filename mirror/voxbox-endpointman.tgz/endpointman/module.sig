-----BEGIN PGP SIGNED MESSAGE-----
Hash: SHA256

;################################################
;#        VoxBox Endpoint Manager module.sig     #
;################################################
;# Local signature. Hashes live in the root-owned #
;# file /etc/freepbx.secure/endpointman.sig.      #
;################################################

[config]
version=2
hash=sha256
type=local
signedwith=55D46506ED591342
signedby='Binary Systems, Inc. <modules@binary-systems.com>'
repo=standard
timestamp=1792727786.9168
[hashes]
endpointman.sig = 1bd22b13613d8c3420d6eefa6534e88c38cda147698f5840b93c630e7d93d07e
-----BEGIN PGP SIGNATURE-----

iQIzBAEBCAAdFiEEF+PiQ9s2pyy7ggTkVdRlBu1ZE0IFAmra5bAACgkQVdRlBu1Z
E0I/wA/+PSnVyDX4rfiLLrg70+XUHo9TWVVWdiwiJEyNPRY4Cv8SM4+hhoH4k3Or
Dbf5geSt3mDN3AfngLJN28Mpa0l8I0AT3XcVl7l5Rl9xjU0Z7FnwE1qd1X/4FmDv
m26gLDQPoopm4PnScmgBKKa9GHhYwdJWfg2+kAAIGqSh+dfi3b77OVluvH/NJlvL
/Eaauh3px2PPYqqUQsl9a1Qbq84KVq+QICSH55jiON+/SA5ZPtpARB69HZeOfYEA
Xkg5HraZtZ3DvflYo9DxNgI0rkW2udM9yQNQOb38BQEHlH/JN3hPPERJzMpztUJG
EaM3k2uLFeF6ePrbsLkSjz5d2Qg/qDmtHYShIHhFFhAqTb3JMSWRUusgefyDxKh3
Yf2tNUPBX+hqpAb7oRFElU0RIfhL3z4DbK6qwZaWHfHoy65VPOkH499InfyXF72k
HL+oWA+Etkmxlosy2Q8WnhIjIRVIC8Bi4IxRS9r1/rAXCfTKu7pqfO3jUc6sFaB/
dIvp4lY42hJLegJReRgPry/G+UZIHP9Jyl3K+JUtNgFM0xgB7B/Jadmfq7HO6wz5
vxW1tbd7+H7ISpKEkoUAPhOsylREVx7ney1ja5/HmsHN1iJmazsPWDfcaLsnoQ30
3MUXR/DmsGjwYBYXlib/eOu5X601AMer8nLk0dGW849ywAYLujo=
=NwIZ
-----END PGP SIGNATURE-----
