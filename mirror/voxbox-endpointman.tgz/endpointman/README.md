# VoxBox Endpoint Manager

FreePBX 17 module that provisions phones for VoxBox, including older Polycom SoundPoint and SoundStation models.

The FreePBX raw name stays `endpointman`, so this package upgrades an existing OSS Endpoint Manager install and keeps its database. The menu name is **VoxBox Endpoint Manager**.

## License

GPLv3+. This package is based on [FreePBX endpointman](https://github.com/FreePBX/endpointman) 17.0.1 and the [Provisioner](https://github.com/provisioner/Provisioner) library. See `LICENSE`.

## Install on FreePBX 17

From a VoxBox install, `VoxBox2026.sh` and `VoxBox2026-EL.sh` load `mirror/voxbox-endpointman.tgz` and run `fwconsole ma install endpointman`.

To load the package by itself:

```bash
tar -C /tmp -xzf voxbox-endpointman.tgz
rm -rf /var/www/html/admin/modules/endpointman
mv /tmp/endpointman /var/www/html/admin/modules/endpointman
fwconsole ma install endpointman
php /var/www/html/admin/modules/endpointman/install/voxbox-provisioner.php
```

Phone brand files, including Polycom `splm`, still come from the VoxBox `mirror/ossepm16.tgz` tree at `/var/www/html/admin/modules/_ep_phone_modules`. Install those before `install/voxbox-provisioner.php`. That script patches the provisioner for PHP 8 and enables the Polycom models.

## Package

`build-package.sh` writes `dist/voxbox-endpointman.tgz` with `endpointman/module.xml` at the archive root. FreePBX module version is 17.1.5.
