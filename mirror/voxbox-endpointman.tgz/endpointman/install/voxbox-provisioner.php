<?php
/**
 * VoxBox Endpoint Manager provisioner fix.
 *
 * PHP 8 stops config generation on warnings. This patches the phone-module
 * autoload and Polycom base class, enables the older Polycom models, and
 * installs the Binary Systems SoundPoint backgrounds.
 * Safe to run more than once.
 *
 *   php install/voxbox-provisioner.php
 */

function voxbox_epm_provisioner_fix($phone = null)
{
    if ($phone === null || $phone === '') {
        $phone = '/var/www/html/admin/modules/_ep_phone_modules';
    }
    $notes = array();

    $autoload = $phone . '/autoload.php';
    if (!is_file($autoload)) {
        $notes[] = "missing $autoload";
    } else {
        $text = file_get_contents($autoload);
        $orig = $text;
        if (strpos($text, 'rtrim((string)') !== false || strpos($text, 'buildPath') !== false) {
            // already joins the module directory with a slash
        } elseif (strpos($text, 'PROVISIONER_BASE') !== false && strpos($text, 'PHONE_MODULES_PATH') === false) {
            // older loader uses PROVISIONER_BASE, which already has a trailing slash
        } else {
            $needle = '\\FreePBX::Endpointman()->PHONE_MODULES_PATH . $file';
            $fixed = "rtrim((string) \\FreePBX::Endpointman()->PHONE_MODULES_PATH, '/') . '/' . \$file";
            if (strpos($text, $needle) === false) {
                $notes[] = 'autoload.php path join was not recognized';
            } else {
                $text = str_replace($needle, $fixed, $text);
            }
        }
        if ($text !== $orig) {
            file_put_contents($autoload, $text);
            $notes[] = "patched $autoload";
        }
    }

    $base = $phone . '/endpoint/base.php';
    if (!is_file($base)) {
        $notes[] = "missing $base";
    } else {
        $text = file_get_contents($base);
        $orig = $text;
        if (strpos($text, 'private $epm_extra') === false) {
            $ctor = "    function __construct() {\n        \$this->root_dir = empty(\$this->root_dir) ? dirname(dirname(__FILE__)) . \"/\" : \$this->root_dir;\n    }\n";
            $ctor_new = $ctor . "\n    private \$epm_extra = array();\n\n    public function __set(\$name, \$value) {\n        \$this->epm_extra[\$name] = \$value;\n    }\n\n    public function __get(\$name) {\n        return \$this->epm_extra[\$name] ?? null;\n    }\n\n    public function __isset(\$name) {\n        return isset(\$this->epm_extra[\$name]);\n    }\n";
            if (strpos($text, $ctor) === false) {
                $notes[] = 'endpoint base.php constructor was not recognized';
            } else {
                $text = str_replace($ctor, $ctor_new, $text);
            }
        }
        $text = str_replace(
            "if (\$key1['1'] == 'variable') {",
            "if (is_array(\$key1) && isset(\$key1[1]) && \$key1[1] == 'variable') {",
            $text
        );
        $text = str_replace(
            "} elseif (\$key1['4'] == 'variable') {",
            "} elseif (is_array(\$key1) && isset(\$key1[4]) && \$key1[4] == 'variable') {",
            $text
        );
        $tz = "        \$result.=(int) (\$offset / 3600);\n        if (\$result % 3600 > 0) {";
        $tz_new = "        \$result.=(int) (\$offset / 3600);\n        if (\$offset % 3600 > 0) {";
        if (strpos($text, $tz) !== false) {
            $text = str_replace($tz, $tz_new, $text);
        }
        if ($text !== $orig) {
            file_put_contents($base, $text);
            $notes[] = "patched $base";
        }
    }

    $sip = $phone . '/endpoint/polycom/spipm/sip.cfg';
    if (is_file($sip)) {
        $sip_text = file_get_contents($sip);
        $sip_new = str_replace(
            'tcpIpApp.sntp.address.overrideDHCP="{$sntp_overrideDHCP|1}"',
            'tcpIpApp.sntp.address.overrideDHCP="{$sntp_address_overrideDHCP|0}"',
            $sip_text
        );
        $sip_new = str_replace(
            'tcpIpApp.sntp.gmtOffset.overrideDHCP="{$sntp_overrideDHCP|1}"',
            'tcpIpApp.sntp.gmtOffset.overrideDHCP="{$sntp_gmt_overrideDHCP|1}"',
            $sip_new
        );
        $sip_new = str_replace(
            'tcpIpApp.sntp.daylightSavings.enable="{$daylightSavings_enable|0}"',
            'tcpIpApp.sntp.daylightSavings.enable="{$daylightSavings_enable|1}"',
            $sip_new
        );
        // UC Software 4.0.2 accepts YYYY/MM/DD and rejects YYYY.MM.DD, which
        // leaves the idle date as "Wed, Oct 21". The language clock overrides
        // lcl.datetime. device.set forces the value over a choice saved on the handset.
        if (strpos($sip_new, 'YYYY.MM.DD') !== false) {
            $sip_new = str_replace('YYYY.MM.DD', 'YYYY/MM/DD', $sip_new);
        }
        $clock = 'lcl.ml.lang.clock.1.format="YYYY/MM/DD"';
        $old_clock = "  <lcl>\n"
            . "     <lcl.datetime\n"
            . "       lcl.datetime.date.format=\"YYYY/MM/DD\"\n"
            . "       lcl.datetime.date.longFormat=\"0\"\n"
            . "       lcl.datetime.date.dateTop=\"1\"\n"
            . "       lcl.datetime.time.24HourClock=\"1\"/>\n"
            . "  </lcl>\n";
        if (strpos($sip_new, $old_clock) !== false) {
            $sip_new = str_replace($old_clock, '', $sip_new);
        }
        if (strpos($sip_new, $clock) === false && strpos($sip_new, '</polycomConfig>') !== false) {
            $clock_attrs = '';
            for ($i = 1; $i <= 19; $i++) {
                $clock_attrs .= "          lcl.ml.lang.clock.$i.format=\"YYYY/MM/DD\"\n"
                    . "          lcl.ml.lang.clock.$i.format.set=\"1\"\n"
                    . "          lcl.ml.lang.clock.$i.24HourClock=\"1\"\n"
                    . "          lcl.ml.lang.clock.$i.24HourClock.set=\"1\"\n"
                    . "          lcl.ml.lang.clock.$i.dateTop=\"1\"\n"
                    . "          lcl.ml.lang.clock.$i.dateTop.set=\"1\"\n"
                    . "          lcl.ml.lang.clock.$i.longFormat=\"0\"\n";
            }
            $block = "  <device device.set=\"1\"/>\n"
                . "  <lcl>\n"
                . "     <lcl.ml>\n"
                . "        <lcl.ml.lang.clock\n"
                . $clock_attrs
                . "          />\n"
                . "     </lcl.ml>\n"
                . "     <lcl.datetime\n"
                . "       lcl.datetime.date.format=\"YYYY/MM/DD\"\n"
                . "       lcl.datetime.date.format.set=\"1\"\n"
                . "       lcl.datetime.date.longFormat=\"0\"\n"
                . "       lcl.datetime.date.longFormat.set=\"1\"\n"
                . "       lcl.datetime.date.dateTop=\"1\"\n"
                . "       lcl.datetime.date.dateTop.set=\"1\"\n"
                . "       lcl.datetime.time.24HourClock=\"1\"\n"
                . "       lcl.datetime.time.24HourClock.set=\"1\"/>\n"
                . "  </lcl>\n";
            $sip_new = str_replace('</polycomConfig>', $block . '</polycomConfig>', $sip_new);
        }
        if ($sip_new !== $sip_text) {
            file_put_contents($sip, $sip_new);
            $notes[] = 'Polycom time template uses the local router, Dallas daylight saving, and a 24-hour YYYY/MM/DD clock';
        }
    }

    $reg = $phone . '/endpoint/polycom/spipm/$mac_reg.cfg';
    if (is_file($reg)) {
        $reg_text = file_get_contents($reg);
        $reg_new = str_replace(
            'call.autoAnswer.SIP="0"',
            'call.autoAnswer.SIP="1"',
            $reg_text
        );
        if ($reg_new !== $reg_text) {
            file_put_contents($reg, $reg_new);
            $notes[] = 'enabled Polycom SIP auto-answer for intercom';
        }
    }

    $phone_php = $phone . '/endpoint/polycom/spipm/phone.php';
    if (!is_file($phone_php)) {
        $notes[] = "missing $phone_php";
    } else {
        $php = file_get_contents($phone_php);
        $tz_marker = 'VoxBox writes the standard offset';
        if (strpos($php, $tz_marker) === false) {
            $close = strrpos($php, '}');
            if ($close === false) {
                $notes[] = 'SoundPoint IP phone class could not be patched';
            } else {
                $method = <<<'PHP'

    protected function setup_timezone() {
        // VoxBox writes the standard offset. This Polycom adds US daylight
        // saving itself. Sending the current offset makes the clock an hour
        // fast while daylight time is in effect.
        if (!isset($this->DateTimeZone) || !is_object($this->DateTimeZone)) {
            throw new Exception('You Must define a valid DateTimeZone object');
        }
        $zone = $this->DateTimeZone;
        $year = (new DateTime('now', $zone))->format('Y');
        $utc = new DateTimeZone('UTC');
        $start = (new DateTime($year . '-01-01 00:00:00', $utc))->getTimestamp();
        $end = (new DateTime(((int) $year + 1) . '-01-01 00:00:00', $utc))->getTimestamp();
        $standard = $zone->getOffset(new DateTime('now', $zone));
        $transitions = $zone->getTransitions($start, $end);
        if (is_array($transitions)) {
            foreach ($transitions as $transition) {
                if (empty($transition['isdst'])) {
                    $standard = (int) $transition['offset'];
                    break;
                }
            }
        }
        $offset = $standard;
        if ($offset < 0) {
            $label = 'GMT-';
            $offset = abs($offset);
        } else {
            $label = 'GMT+';
        }
        $label .= (int) ($offset / 3600);
        if ($offset % 3600 > 0) {
            $label .= ':' . (int) (($offset % 3600) / 60);
        } else {
            $label .= ':00';
        }
        $this->timezone = array(
            'gmtoffset' => $standard,
            'timezone' => $label,
        );
    }

PHP;
                $php = substr($php, 0, $close) . $method . substr($php, $close);
                file_put_contents($phone_php, $php);
                $notes[] = 'SoundPoint IP phones now send the standard time offset';
            }
        }
    }

    $notes = array_merge($notes, voxbox_polycom_backgrounds($phone));

    $compiled = dirname(__DIR__) . '/templates/freepbx/compiled';
    if (!is_dir($compiled)) {
        @mkdir($compiled, 0775, true);
    }

    if (class_exists('FreePBX', false)) {
        try {
            $db = \FreePBX::Database();
            $db->query(
                "UPDATE endpointman_model_list m
                 JOIN endpointman_brand_list b ON b.id = m.brand
                 SET m.enabled = 1
                 WHERE b.directory = 'polycom' AND m.hidden = 0"
            );
            $notes[] = 'enabled Polycom models';
            $notes = array_merge($notes, voxbox_polycom_template($db));
        } catch (\Throwable $e) {
            $notes[] = 'Polycom model enable failed: ' . $e->getMessage();
        }
    }

    return $notes;
}

/**
 * SoundPoint IP 670 color screens sampled from the Binary Systems animation.
 * Slot 6 is the finished logo and is the idle image. Gray and 450 screens stay stock.
 */
function voxbox_polycom_backgrounds($phone)
{
    $notes = array();
    $family = $phone . '/endpoint/polycom/spipm';
    if (!is_dir($family)) {
        $notes[] = "missing $family";
        return $notes;
    }

    $names = array();
    for ($i = 1; $i <= 6; $i++) {
        $names[] = 'BSI-' . $i . '.jpg';
        $names[] = 'BSI-' . $i . 'EM.jpg';
    }
    $src = dirname(__FILE__) . '/polycom-backgrounds';
    $copied = 0;
    foreach ($names as $name) {
        $from = $src . '/' . $name;
        if (!is_file($from)) {
            $notes[] = "missing background $name";
            continue;
        }
        $to = $family . '/' . $name;
        if (is_file($to) && md5_file($from) === md5_file($to)) {
            continue;
        }
        if (!@copy($from, $to)) {
            $notes[] = "could not copy $name";
            continue;
        }
        @chmod($to, 0664);
        $copied++;
    }
    if ($copied) {
        $notes[] = "installed $copied Polycom background images";
    }

    $features = $family . '/features.cfg';
    if (!is_file($features)) {
        $notes[] = 'missing features.cfg';
    } else {
        $text = file_get_contents($features);
        $stock = 'bg.hiRes.color.bm.1.em.name="LeafEM.jpg" bg.hiRes.color.bm.1.name="Leaf.jpg"'
            . ' bg.hiRes.color.bm.2.em.name="SailboatEM.jpg" bg.hiRes.color.bm.2.name="Sailboat.jpg"'
            . ' bg.hiRes.color.bm.3.em.name="BeachEM.jpg" bg.hiRes.color.bm.3.name="Beach.jpg"'
            . ' bg.hiRes.color.bm.4.em.name="PalmEM.jpg" bg.hiRes.color.bm.4.name="Palm.jpg"'
            . ' bg.hiRes.color.bm.5.em.name="JellyfishEM.jpg" bg.hiRes.color.bm.5.name="Jellyfish.jpg"'
            . ' bg.hiRes.color.bm.6.em.name="MountainEM.jpg" bg.hiRes.color.bm.6.name="Mountain.jpg"';
        $bsi = '';
        for ($i = 1; $i <= 6; $i++) {
            if ($bsi !== '') {
                $bsi .= ' ';
            }
            $bsi .= 'bg.hiRes.color.bm.' . $i . '.em.name="BSI-' . $i . 'EM.jpg"';
            $bsi .= ' bg.hiRes.color.bm.' . $i . '.name="BSI-' . $i . '.jpg"';
        }
        $updated = $text;
        if (strpos($updated, $stock) !== false) {
            $updated = str_replace($stock, $bsi, $updated);
        }
        if (strpos($updated, 'bg.hiRes.color.bm.1.name="BSI-1.jpg"') !== false
            && strpos($updated, 'bg.hiRes.color.selection="1,1"') !== false) {
            $updated = str_replace(
                'bg.hiRes.color.selection="1,1"',
                'bg.hiRes.color.selection="3,6"',
                $updated
            );
        }
        if ($updated !== $text) {
            file_put_contents($features, $updated);
            $notes[] = 'SoundPoint color backgrounds use the Binary Systems screens';
        }
    }

    $phone_php = $family . '/phone.php';
    if (!is_file($phone_php)) {
        $notes[] = "missing $phone_php";
        return $notes;
    }
    $php = file_get_contents($phone_php);
    $orig = $php;
    $marker = 'VoxBox Polycom background screens';
    if (strpos($php, $marker) === false) {
        $needle = "        \$this->settings['createdFiles'] = implode(', ', array_values(\$this->configfiles));";
        $replacement = <<<'PHP'
        // VoxBox Polycom background screens. List features.cfg first so the
        // registration file and sip.cfg still win on time and intercom.
        if (!isset($result['features.cfg'])) {
            $result['features.cfg'] = 'features.cfg';
        }
        $created = array_values($this->configfiles);
        if (!in_array('features.cfg', $created, true)) {
            array_unshift($created, 'features.cfg');
        }
        $this->settings['createdFiles'] = implode(', ', $created);
PHP;
        if (strpos($php, $needle) === false) {
            $notes[] = 'SoundPoint config file list was not recognized';
        } else {
            $php = str_replace($needle, $replacement, $php);
        }
    }
    if (strpos($php, '"BSI-1.jpg"') === false) {
        $beach = "        \"Beach.jpg\",\n";
        $list = $beach;
        foreach ($names as $name) {
            $list .= '        "' . $name . "\",\n";
        }
        if (strpos($php, $beach) === false) {
            $notes[] = 'SoundPoint image copy list was not recognized';
        } else {
            $php = str_replace($beach, $list, $php);
        }
    }
    if ($php !== $orig) {
        file_put_contents($phone_php, $php);
        $notes[] = 'SoundPoint phones load the Binary Systems background screens';
    }
    return $notes;
}

/**
 * Dallas (America/Chicago) Polycom template. Daylight saving is the US rule:
 * second Sunday in March through the first Sunday in November.
 */
function voxbox_default_gateway()
{
    $lines = @file('/proc/net/route');
    if (!$lines) {
        return '';
    }
    foreach ($lines as $line) {
        $fields = preg_split('/\s+/', trim($line));
        if (count($fields) < 3 || $fields[1] !== '00000000') {
            continue;
        }
        $hex = $fields[2];
        if (!preg_match('/^[0-9A-Fa-f]{8}$/', $hex) || strcasecmp($hex, '00000000') === 0) {
            continue;
        }
        return implode('.', array(
            hexdec(substr($hex, 6, 2)),
            hexdec(substr($hex, 4, 2)),
            hexdec(substr($hex, 2, 2)),
            hexdec(substr($hex, 0, 2)),
        ));
    }
    return '';
}

function voxbox_polycom_template($db)
{
    $notes = array();
    $ntp = voxbox_default_gateway();
    if ($ntp === '') {
        $ntp = '10.10.0.10';
    }
    $settings = serialize(array(
        'srvip' => '10.10.0.10',
        'config_location' => '/tftpboot/',
        'server_type' => 'file',
        'ntp' => $ntp,
        'tz' => 'America/Chicago',
    ));
    $found = $db->prepare("SELECT id FROM endpointman_template_list WHERE name = 'VoxBox-Polycom' LIMIT 1");
    $found->execute();
    $template_id = $found->fetchColumn();
    if (!$template_id) {
        $model = $db->query("SELECT id, product_id FROM endpointman_model_list WHERE id = 4439")->fetch(\PDO::FETCH_ASSOC);
        if (empty($model['id'])) {
            $notes[] = 'SoundPoint IP 670 model is not installed; VoxBox-Polycom template was not created';
            return $notes;
        }
        $insert = $db->prepare(
            "INSERT INTO endpointman_template_list (product_id, model_id, name, global_settings_override)
             VALUES (:product_id, :model_id, 'VoxBox-Polycom', :settings)"
        );
        $insert->execute(array(
            'product_id' => $model['product_id'],
            'model_id' => $model['id'],
            'settings' => $settings,
        ));
        $template_id = $db->lastInsertId();
        $notes[] = 'created VoxBox-Polycom template';
    } else {
        $update = $db->prepare("UPDATE endpointman_template_list SET global_settings_override = :settings WHERE id = :id");
        $update->execute(array('settings' => $settings, 'id' => $template_id));
    }

    $assign = $db->prepare(
        "UPDATE endpointman_mac_list
         SET template_id = :template_id
         WHERE model = 4439 AND template_id IN (0, 1, :current_id)"
    );
    $assign->execute(array(
        'template_id' => $template_id,
        'current_id' => $template_id,
    ));

    $phones = $db->prepare("SELECT id FROM endpointman_mac_list WHERE template_id = :template_id");
    $phones->execute(array('template_id' => $template_id));
    $ids = $phones->fetchAll(\PDO::FETCH_COLUMN);
    if (!$ids) {
        return $notes;
    }

    require_once dirname(__DIR__) . '/includes/functions.inc';
    $endpoint = new \endpointmanager(\FreePBX::Endpointman());
    foreach ($ids as $mac_id) {
        $info = $endpoint->get_phone_info($mac_id);
        if (!is_array($info)) {
            $notes[] = 'could not read phone ' . $mac_id;
            continue;
        }
        ob_start();
        $wrote = $endpoint->prepare_configs($info, false);
        ob_end_clean();
        $notes[] = $wrote ? 'rebuilt VoxBox-Polycom config' : 'config rebuild failed';
    }
    return $notes;
}

if (PHP_SAPI === 'cli' && isset($_SERVER['SCRIPT_FILENAME']) && realpath($_SERVER['SCRIPT_FILENAME']) === __FILE__) {
    $bootstrap = '/etc/freepbx.conf';
    if (is_file($bootstrap)) {
        $bootstrap_settings['freepbx_auth'] = false;
        include $bootstrap;
    }
    $notes = voxbox_epm_provisioner_fix();
    foreach ($notes as $note) {
        echo $note . "\n";
    }
    if (!$notes) {
        echo "VoxBox Endpoint Manager provisioner already in place\n";
    }
}
