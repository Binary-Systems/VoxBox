<?php
global $active_modules;

if (!empty($active_modules['endpoint']['rawname'])) {
	if (FreePBX::Endpointman()->getConfig("disable_endpoint_warning") !== "1") {
		include('page.epm_warning.php');  
	}
}
?>
<?PHP

/**
 * Endpoint Manager Master Page File
 *
 * @author Andrew Nagy
 * @license MPL / GPLv2 / LGPL
 * @package Endpoint Manager
 */

require_once dirname(__FILE__).'/config.php';

$module_path = FreePBX::Endpointman()->MODULE_PATH;


switch ($page) {
    case 'advanced':
        include $module_path . '/includes/advanced.inc';
        break;
    case 'epm_oss':
        include $module_path . '/includes/advanced.inc';
        break;

    case 'template_manager':
        include $module_path . '/includes/template_manager.inc';
        break;

    case 'devices_manager';
        include $module_path . '/includes/devices_manager.inc';
        break;

    case 'brand_model_manager':
        include $module_path . '/includes/brand_model_manager.inc';
        break;

    case 'installer':
        include $module_path . '/install.inc';
        break;

    default:
        include $module_path . '/includes/devices_manager.inc';
		
}