<?php if (!defined('FREEPBX_IS_AUTH')) { die('No direct script access allowed'); } ?>

<?= $endpoint_warn ?>
<div class="alert alert-info" role="alert">
	<h3 class="alert-heading"><?= _('Open Source Information') ?></h3>
  	<p><?= _('VoxBox Endpoint Manager provisions phones for VoxBox, including older Polycom SoundPoint and SoundStation models.') ?></p>
	<p><?= _('This package is based on the GPLv3+ OSS Endpoint Manager. Upstream: <a href="https://github.com/FreePBX/endpointman" class="alert-link" rel="nofollow">FreePBX endpointman</a> and <a href="https://github.com/provisioner/Provisioner" class="alert-link" rel="nofollow">Provisioner</a>.') ?></p>
	<p><?= _('The VoxBox package is at <a href="https://gitea.binary-systems.com/binary-systems.com/VoxBox-EndpointMan" class="alert-link" rel="nofollow">binary-systems.com/VoxBox-EndpointMan</a>.') ?></p>
	<br>
  	<div class="alert alert-warning" role="alert">
		<?= _('This is not the same at the commercial EPM and It is <strong>NOT</strong> supported by FreePBX or Sangoma Technologies inc. If you are looking for a Commercially supported endpoint manager please look into the Commercial Endpoint Manager by <span>Sangoma Technologies inc</span>') ?>
	</div>
</div>