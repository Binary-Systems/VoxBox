#!/bin/bash
# Build a FreePBX-loadable tarball. The archive root directory is endpointman/.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
STAGE="$(mktemp -d /tmp/voxbox-epm-build.XXXXXX)"
mkdir -p "$STAGE/endpointman" "$ROOT/dist"
rsync -a \
  --exclude .git \
  --exclude node_modules \
  --exclude dist \
  --exclude 'templates/freepbx/compiled' \
  "$ROOT/" "$STAGE/endpointman/"
tar -C "$STAGE" -czf "$ROOT/dist/voxbox-endpointman.tgz" endpointman
rm -rf "$STAGE"
echo "Built $ROOT/dist/voxbox-endpointman.tgz"
