# .bash_profile

# Get the aliases and functions
if [ -f ~/.bashrc ]; then
	. ~/.bashrc
fi

# User specific environment and startup programs

PATH=$PATH:$HOME/bin

export PATH
export PS1="WARNING: Always run VoxBox behind a secure firewall.  \n\[$(tput setaf 2)\]\u@\h:\w $ \[$(tput sgr0)\]"
/root/update-VoxBox
pbxstatus -p

